function fnDrawCategoriasElements(){let t="";inmuebles.data.forEach(n=>{t+=`<div class="col-md-4 col-sm-12">
    <figure class="card card-product">
    <div class="img-wrap"><img src="${ASSETURL}/${n.portada}">
    </div>
    <figcaption class="info-wrap">
    
    <h4 class="title text-uppercase tex-center my-2">${n.tipo}</h4>
    <div class="label-rating">Cod: ${n.codigo} </div>
    <hr>
    
    <div class="label-rating"><i class="fa fa-map-marker" aria-hidden="true"></i>
    Dpto: ${n.departamento} </div>
    <div class="label-rating"><i class="fa fa-map-marker" aria-hidden="true"></i>
    Ciudad: ${n.ciudad} </div>
    <div class="label-rating"><i class="fa fa-map-marker" aria-hidden="true"></i>
    Direccion: ${n.direccion} </div>
    
    <p class="desc">${n.descripcion}</p>
    <div class="rating-wrap">
    <ul class="rating-stars">
    <li style="width:80%" class="stars-active">
    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
    class="fa fa-star"></i><i class="fa fa-star"></i>
    </li>
    <li>
    <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i
    class="fa fa-star"></i><i class="fa fa-star"></i>
    </li>
    </ul>
    <hr>
    
    ${n.tipo!="local"&&n.tipo!="bodega"?' <div class="label-rating"><i class="fa fa-bed" aria-hidden="true"><\/i> '+n.habitaciones+" Habitaciones<\/div>":""}</div>
    
    <div class="label-rating"><i class="fa fa-bath" aria-hidden="true"></i>
    ${n.habitaciones} Baños</div>
    <div class="label-rating"><i class="fa fa-car" aria-hidden="true"></i>
    ${n.parqueadero} </div>
    
    </figcaption>
    <div class="bottom-wrap">
    <a href="${SITEURLWEB}/inmueble/myg/details/${n.codigo}" class="btn btn-sm btn-primary float-right">ver mas</a>
    <div class="price-wrap h5">
    
    <span class="price-new">
    
    ${n.proposito=="arrendamiento"?"Canon :   $"+n.canon:"Precio :  $"+n.precio}</span>
    
    </div>
    </div>
    </figure>
    </div>
    `});let n=`<li class="page-item disabled"><button class="page-link btn" tabindex="-1"><<</button></li>`;for(let t=1;t<=inmuebles.last_page;t++)n+=`<li class="page-item"><a class="page-link  ${t==inmuebles.current_page?"bg-secondary text-white":""}" href="#top" onClick="navigate(${t})">${t}</a></li>`;n+=`<li class="page-item"><a class="page-link" href="#top" onClick="navigate(${inmuebles.last_page})"> >> </a></li>`;document.getElementById("categorias").innerHTML=t;document.getElementById("paginator").innerHTML=n}function navigate(n){try{const t=await;axios.get(`..${url}?page=${n}`);inmuebles=t.data;console.log(t);fnDrawCategoriasElements()}catch(t){console.error(t)}}function filtrar(n){n.preventDefault();try{const n=new FormData(formFilter),t=await;axios.post(`${formFilter.action}`,n);inmuebles=t.data;fnDrawCategoriasElements()}catch(t){console.error(t)}}let url=window.location.pathname;async;const formFilter=document.getElementById("formFilter");formFilter.addEventListener("submit",filtrar);async;fnDrawCategoriasElements();sub=1;window.location.pathname.split("/")[2]=="locales"&&(sub=2);const aux=window.location.pathname.split("/")[2].slice(0,window.location.pathname.split("/")[2].length-sub);document.getElementById("selectTipo").value=aux
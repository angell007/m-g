function getDescuentos(n){try{const i=await;axios.get(`/${SITEURL}/descuentos/myg/details/${n}`);const r=await;i.data.data;const u=document.getElementById("descuentosDraw");let t="";await;r.forEach(n=>{t+=`
            <hr>
            <small class="text text-danger font-weight-bold ">${n.fecha} ${n.user.name} </small>
            <p class=" text text-black" style="font-size:1.3vw">Concepto: ${n.concepto} <span>${n.valor}</span></p>
            <small class="text text-black">Observación: ${n.observaciones}</small>
          `});u.innerHTML=t}catch(t){console.error(t)}}async;getDescuentos(window.location.pathname.split("/")[4])